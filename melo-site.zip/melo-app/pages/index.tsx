// Voir code dans le canvas — index.tsx contient le code principal
